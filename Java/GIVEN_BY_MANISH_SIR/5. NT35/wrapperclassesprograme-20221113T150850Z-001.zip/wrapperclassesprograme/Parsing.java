class  Parsing
{
public static void main(String s[])
{
int   i1=Integer.parseInt("1010",2);
int   i6=Integer.parseInt("10");
long   i2=Long.parseLong("10");
double d1=Double.parseDouble("3.123");
System.out.println(i1);
System.out.println(i6);
System.out.println(i2);
System.out.println(d1);
}

}