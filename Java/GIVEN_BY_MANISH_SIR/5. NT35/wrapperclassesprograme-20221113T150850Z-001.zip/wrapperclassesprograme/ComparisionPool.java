class  ComparisionPool
{
public static void main(String s[])
{
Integer   i1=new  Integer(10);
Integer   i2=new  Integer(10);
boolean r=i1==i2;
System.out.println(r);

Integer  i3=128;
Integer   i4=128;
r=i3==i4;
System.out.println(r);

}

}