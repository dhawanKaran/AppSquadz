import java.lang.annotation.*;
class Base
{

void show(int x[])
{

}
}
class child extends Base
{
@Override
void show(int  z[])
{

}

}

