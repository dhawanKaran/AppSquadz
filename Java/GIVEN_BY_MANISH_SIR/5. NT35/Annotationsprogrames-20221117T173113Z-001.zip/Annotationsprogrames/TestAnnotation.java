import java.lang.annotation.*; 
class TestDeprecated
{
@Deprecated
static void display()
{
System.out.println("display");
}
}


class TestAnnotation {
   public static void main(String arg[]) {
      new TestAnnotation().doSomeTestNow();
   }
@SuppressWarnings({"checked","deprecation"})
   public void doSomeTestNow() {
   TestDeprecated.display(); 
      
   }
}






//In this example, you are suppressing the deprecation warning for the method listing shown in Example 2. 
//Because the method is suppressed, you are unlikely to view the "deprecation" warning any more.




