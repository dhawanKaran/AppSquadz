class MyAssertion
{
public static void main(String... s)
{
assert  s[0].equals("india"):"error tu pagal hai" ;
System.out.println("ok");
}
}
//use java -ea switch to enable assertion
//use java -da switch to disable assertion