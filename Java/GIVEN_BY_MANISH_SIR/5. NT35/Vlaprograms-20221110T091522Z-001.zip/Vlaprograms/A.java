
class A
{
int x;
}