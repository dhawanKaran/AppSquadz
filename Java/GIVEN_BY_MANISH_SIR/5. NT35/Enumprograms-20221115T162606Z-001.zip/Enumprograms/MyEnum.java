 enum myCars
{
    HONDA,BMW,LANDROVER
};




public class  MyEnum {

    public static void main(String[] args) {
       
        myCars currentcar=myCars.LANDROVER;
       
        System.out.println("My Current Cars is going to be : "+ currentcar);
       
       
    }

}