class   AllDataTypes
{
public static void main(String...  s)
{
Class  c1=int.class;
System.out.println(c1.getName());
Class  c2=char.class;
System.out.println(c2.getName());
Class  c3=float.class;
System.out.println(c3.getName());
Class  c4=double.class;
System.out.println(c4.getName());
Class  c5=long.class;
System.out.println(c5.getName());
Class  c6=boolean.class;
System.out.println(c6.getName());
Class  c7=byte.class;
System.out.println(c7.getName());
Class  c8=short.class;
System.out.println(c8.getName());
Class  c9=void.class;
System.out.println(c9.getName());
}

}