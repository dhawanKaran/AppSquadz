import java.io.*;
class Ps1
{

public static void main(String s[])throws IOException
{
FileOutputStream fout=new FileOutputStream("pss.txt");
PrintStream ps=new PrintStream(fout);
ps.println("hello");
ps.println("hay");
System.out.println("file created");
}
}








/* int x=get();
int get()
{
System.err.println("india");
return 10;
}*/

//System.setOut(ps);
//System.err.println("india");
//System.err.println("hindustan");


//System.setOut(ps);
//System.err.println("india");
//System.err.println("hindustan");
//ps.println("hello");
//ps.println("hay");
//Ps t=new Ps();
//System.err.println(t.x);




//ps.println("lalu");
//ps.println("rabari");
//System.setOut(ps);
//System.err.println("qq");
//System.err.println("aa");
//System.err.println(new Ps().x);