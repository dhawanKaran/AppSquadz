import java.io.*;
class Ps2
{


public static void main(String... s)
{
System.err.println("hello uncle via  err");
System.err.println("hay  aunt  via  err");
}
}

